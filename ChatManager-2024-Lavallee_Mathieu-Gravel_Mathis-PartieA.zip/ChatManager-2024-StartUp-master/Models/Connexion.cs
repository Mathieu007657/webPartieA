﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatManager.Models
{
    public class Connexion
    {
        public int USerId { get; set; }  // Propriété pour stocker l'identifiant de l'utilisateur
        public int Id { get; set; }
        public DateTime LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }

        // Propriété de navigation pour représenter l'utilisateur associé à cette connexion
        public User User { get; set; }
    }
}