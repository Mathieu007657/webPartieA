﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatManager.Models
{
    public class ConnexionRepository : Repository<Connexion> 
    {
        public List<(DateTime, List<Connexion>)> GetList()
        {
            List<(DateTime, List<Connexion>)> listId = new List<(DateTime, List<Connexion>)> ();

            foreach (var connexion in DB.Connexions.ToList().OrderByDescending(x => x.LoginTime))
            {
                bool exist = false;
                for( int i = 0; i < listId.Count; i++ )
                {
                    if (connexion.LoginTime.Date == listId[i].Item1.Date)
                    {
                        listId[i].Item2.Add(connexion);
                        exist = true;
                    }
                }
                if(!exist)
                {
                    listId.Add((DateTime.Now, new List<Connexion> { connexion }));
                }
            }
            return listId;
        }
        public void Delete(DateTime dateTime)
        {
            BeginTransaction();
            foreach(Connexion connexion in DB.Connexions.ToList())
            {
                if (connexion.LoginTime.Date == dateTime.Date)
                {
                    base.Delete(connexion.Id);
                }
            }
            EndTransaction();
        }
    }
}